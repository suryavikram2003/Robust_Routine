package com.example.newapk;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Button buttonSecondActivity = findViewById(
                R.id.idBtnloginambulance
        );
        buttonSecondActivity.setOnClickListener(view -> {
            Intent secondActivityIntent = new Intent(
                    getApplicationContext(), loginhos.class
            );
            startActivity(secondActivityIntent);
        });

        Button policeloginpage = findViewById(
                R.id.idBtnloginpolice
        );
        policeloginpage.setOnClickListener(view -> {
            Intent policesignupIntent = new Intent(
                    getApplicationContext(),policelogin.class
            );
            startActivity(policesignupIntent);
        });

        Button user = findViewById(
                R.id.idBtnloginuser
        );
        user.setOnClickListener(view -> {
            Intent userloginIntent = new Intent(
                    getApplicationContext(),userlogin.class
            );
            startActivity(userloginIntent);
        });


    }
}