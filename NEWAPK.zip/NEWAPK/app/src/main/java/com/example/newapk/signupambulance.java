package com.example.newapk;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;

public class signupambulance extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_signupambulance);

        Button ambusingup = findViewById(
                R.id.button7
        );
        ambusingup.setOnClickListener(view -> {
            Intent ambusingupIntent = new Intent(
                    getApplicationContext(),loginhos.class
            );
            startActivity(ambusingupIntent);
        });

    }
}