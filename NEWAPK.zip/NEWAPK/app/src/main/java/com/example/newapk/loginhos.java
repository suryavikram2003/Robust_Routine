package com.example.newapk;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class loginhos extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_loginhos);

        Button buttonlogonhaospital = findViewById(
                R.id.idBtnLogin
        );
        buttonlogonhaospital.setOnClickListener(view -> {
            Intent hospitalloganActivityIntent = new Intent(
                    getApplicationContext(), mainmenuhospital.class
            );
            startActivity(hospitalloganActivityIntent);
        });

        Button signupambulance = findViewById(
                R.id.button3
        );
        signupambulance.setOnClickListener(view -> {
            Intent signupambulanceIntent = new Intent(
                    getApplicationContext(), signupambulance.class
            );
            startActivity(signupambulanceIntent);
        });


    }
}