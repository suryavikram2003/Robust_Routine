package com.example.newapk;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;

public class ReviewRecent extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_review_recent);
    }
}