package com.example.newapk;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;

public class policelogin extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_policelogin);


        Button pclogin = findViewById(
                R.id.button9
        );
        pclogin.setOnClickListener(view -> {
            Intent pcloginIntent = new Intent(
                    getApplicationContext(),policesignup.class
            );
            startActivity(pcloginIntent);
        });

        Button pcmm = findViewById(
                R.id.button
        );
        pcmm.setOnClickListener(view -> {
            Intent pcmmIntent = new Intent(
                    getApplicationContext(),PoliceDeptpage.class
            );
            startActivity(pcmmIntent);
        });
    }
}