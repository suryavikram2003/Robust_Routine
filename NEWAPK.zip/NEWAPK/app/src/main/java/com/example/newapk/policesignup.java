package com.example.newapk;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class policesignup extends AppCompatActivity {


    policesignup binding;
    String name , station_no ,phone, state ,district ,batch_no,password;
    FirebaseDatabase db;
    DatabaseReference reference;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_policesignup);

        Button buttonSecondActivity = findViewById(
                R.id.button2
        );
        buttonSecondActivity.setOnClickListener(view -> {
            Intent secondActivityIntent = new Intent(
                    getApplicationContext(), policelogin.class
            );
            startActivity(secondActivityIntent);
        });
    }
}