package com.example.newapk;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class mainmenuhospital extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_mainmenuhospital);
    }
}